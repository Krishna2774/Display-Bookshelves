package Drivers;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.opera.OperaDriver;

public class DriverSetup {

	static String URL;
	static String location;
	static WebDriver driver;
	public static String userDir = System.getProperty("user.dir");

	public static WebDriver getDriver() {

		String Browser = "Chrome";
		if (Browser.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver", userDir + "\\driver\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (Browser.equalsIgnoreCase("Firefox")) {
			System.setProperty("webdriver.gecko.driver", userDir + "\\driver\\geckodriver.exe");
			FirefoxOptions fo = new FirefoxOptions();
			driver= new FirefoxDriver(fo);
		} else if (Browser.equalsIgnoreCase("Edge")) {
				System.setProperty("webdriver.edge.driver", userDir + "\\driver\\msedgedriver.exe");
				driver = new EdgeDriver();
		} else {
			System.setProperty("webdriver.opera.driver", userDir + "\\driver\\operadriver.exe");
			driver = new OperaDriver();
		}

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.get("https://www.urbanladder.com/");
		driver.manage().window().maximize();
		return driver;
	}
}

